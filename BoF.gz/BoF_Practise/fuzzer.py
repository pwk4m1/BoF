

import subprocess

def fuzz(buf):
	proc = subprocess.Popen(["dnstracer", str(buf)], stdout=subprocess.PIPE)
	proc.communicate()
	if (proc.returncode != 0): return 1
	return 0


x = 1000
while True:
	print "Running: dnstracer, argv[1] = %d * A. press enter if program freezes." % x
	if (fuzz("\x41" * x)): break
	x += 1

print "Found crash with : %d * A " % x

