#!/usr/bin/env python2.7
from socket import *
from threading import Thread
import time

def append_file(msg):
	try:
		f = open("dns_server.log", "a")
	except:
		time.sleep(0.2)
		try:
			f = open("dns_server.log", "a")
		except:
			return 0
	f.write(msg)
	f.close()

def tcp_log(msg):
	msg = "\n [TCP] " + msg
	print msg
	append_file(msg)

def udp_log(msg):
	msg = "\n [UDP] " + msg
	print msg
	append_file(msg)

class server(object):
	def __init__(self):
		self.running = 0
		self.threads = 0

	@staticmethod
	def bind_tcp_socket():
		sock = socket(AF_INET, SOCK_STREAM)
		try:
			sock.bind(("0.0.0.0", 53))
		except Exception as Err:
			tcp_log(str(Err))
			sock = 0
		return sock
	
	@staticmethod
	def bind_udp_socket():
		sock = socket(AF_INET, SOCK_DGRAM)
		try:
			sock.bind(("0.0.0.0", 53))
		except Exception as Err:
			udp_log(str(Err))
			return 0
		return sock

	def serve_tcp(self, sock):
		tcp_log("Started to serve at tcp:53")
		while True:
			try:
				sock.listen(1)
				conn, addr = sock.accept()
				tcp_log("Client from %s." % str(addr))
				conn.send("0000")
				conn.close()
			except Exception as Err:
				tcp_log(str(Err))
				break

	def serve_udp(self, sock):
		udp_log("Started to serve at udp:53")
		while True:
			try:
				data, addr = sock.recvfrom(4096)
				udp_log("Client from %s." % str(addr))
				sock.sendto("0000", addr)
			except Exception as Err:
				udp_log(str(Err))
				break

	def serve(self):
		tcp_sock = server.bind_tcp_socket()
		udp_sock = server.bind_udp_socket()
		if ((not tcp_sock) or (not udp_sock)):
			return 0
		Thread(target=self.serve_tcp, args=(tcp_sock,)).start()
		Thread(target=self.serve_udp, args=(udp_sock,)).start()

se = server()
se.serve()

