#!/bin/sh
set -e
cd dnstracer-1.9
make
make install
cd ../
cp -v gdbinit ~/.gdbinit
cp -rv peda ~/peda
cp -v fuzzer.py /usr/bin/dnstracef.py
cp -v gen_shellcode.py /usr/bin/gen_shellcode.py

echo 0 > /proc/sys/kernel/randomize_va_space
rm -rf /etc/resolv.conf
echo "nameserver 127.0.0.1" >> /etc/resolv.conf
echo "nameserver 8.8.8.8" >> /etc/resolv.conf
touch dns_server.log
screen -d -m python dns_server.py


