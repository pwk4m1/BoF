#!/bin/sh
set -e
cd dnstracer-1.9
make
make install
cd ../
cp -v gdbinit ~/.gdbinit
cp -rv peda ~/peda
cp -v fuzzer.py /usr/bin/dnstracef.py
cp -v gen_shellcode.py /usr/bin/gen_shellcode.py

echo 0 > /proc/sys/kernel/randomize_va_space


